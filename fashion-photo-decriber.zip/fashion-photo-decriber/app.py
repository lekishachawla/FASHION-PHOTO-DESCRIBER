import os
from flask import Flask, render_template, request
import cv2
import numpy as np

app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def analyze_outfit_colors(img):
    """
    Comprehensive outfit analysis including:
    - Dominant color palette
    - Warm/Cool tone detection
    - Fashion style summary (vibe, colors, garment layout)
    """
    height, width = img.shape[:2]
    scale = min(1, 240 / max(height, width))
    sample = cv2.resize(img, (max(1, int(width * scale)), max(1, int(height * scale))))
    hsv = cv2.cvtColor(sample, cv2.COLOR_BGR2HSV)
    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]
    total_pixels = sample.shape[0] * sample.shape[1]

    neutral = cv2.inRange(hsv, (0, 0, 0), (179, 34, 255))
    black = cv2.inRange(value, 0, 44)
    white = cv2.inRange(value, 205, 255)
    gray = cv2.inRange(value, 45, 204)
    black = cv2.bitwise_and(black, neutral)
    white = cv2.bitwise_and(white, neutral)
    gray = cv2.bitwise_and(gray, neutral)

    def hue_mask(low, high, min_value=0):
        return cv2.inRange(hsv, (low, 35, min_value), (high, 255, 255))

    red = cv2.bitwise_or(hue_mask(0, 4), hue_mask(170, 179))
    yellow = cv2.bitwise_or(
        hue_mask(19, 24, 146),
        hue_mask(25, 34),
    )
    colors = [
        ("black", black, "#202020"),
        ("white", white, "#f7f5f2"),
        ("gray", gray, "#888888"),
        ("brown", cv2.inRange(hsv, (5, 35, 0), (24, 255, 145)), "#795548"),
        ("red", red, "#d94343"),
        ("orange", hue_mask(5, 18, 146), "#ec8733"),
        ("yellow", yellow, "#e5c33b"),
        ("green", hue_mask(35, 84), "#4e9955"),
        ("blue", hue_mask(85, 124), "#477bb5"),
        ("purple", hue_mask(125, 154), "#8753a1"),
        ("pink", hue_mask(155, 169), "#d8759d"),
    ]

    color_results = []
    neutral_pixels = 0
    warm_pixels = 0  # Red, orange, yellow, brown
    cool_pixels = 0  # Blue, purple, green
    
    for name, mask, swatch in colors:
        count = cv2.countNonZero(mask)
        if name in {"black", "white", "gray"}:
            neutral_pixels += count
        elif name in {"red", "orange", "yellow", "brown"}:
            warm_pixels += count
        elif name in {"blue", "purple", "green"}:
            cool_pixels += count
            
        percentage = round(count * 100 / total_pixels)
        if percentage >= 5:
            color_results.append({
                "name": name.title(),
                "percentage": percentage,
                "swatch": swatch,
            })

    color_results.sort(key=lambda color: color["percentage"], reverse=True)
    dominant_colors = color_results[:4]
    
    # Determine warm/cool tone
    total_chromatic = warm_pixels + cool_pixels
    if total_chromatic > 0:
        warm_ratio = warm_pixels / total_chromatic
        if warm_ratio >= 0.65:
            tone_classification = "Warm"
            tone_description = "Warm undertones with energetic, sunny vibes"
        elif warm_ratio <= 0.35:
            tone_classification = "Cool"
            tone_description = "Cool undertones with calm, refined vibes"
        else:
            tone_classification = "Neutral"
            tone_description = "Balanced warm and cool tones for versatility"
    else:
        tone_classification = "Neutral"
        tone_description = "Neutral palette with understated tones"

    average_saturation = cv2.mean(saturation)[0]
    gray_image = cv2.cvtColor(sample, cv2.COLOR_BGR2GRAY)
    contrast = cv2.meanStdDev(gray_image)[1][0][0]

    # Determine palette mood
    if neutral_pixels / total_pixels >= 0.65:
        palette_mood = "Minimalist & Understated"
        vibe = "Chic and effortless"
        style_category = "Neutral Elegance"
    elif average_saturation >= 115:
        palette_mood = "Bold & Vibrant"
        vibe = "Confident and expressive"
        style_category = "Statement Style"
    else:
        palette_mood = "Balanced & Harmonious"
        vibe = "Polished and refined"
        style_category = "Timeless Classic"

    contrast_description = "High contrast" if contrast >= 60 else "Soft contrast" if contrast < 32 else "Moderate contrast"

    # Analyze garment layout by image zones
    h, w = sample.shape[:2]
    top_third = sample[0:h//3, :]
    middle_third = sample[h//3:2*h//3, :]
    bottom_third = sample[2*h//3:h, :]
    
    def get_dominant_zone_color(zone):
        if zone.size == 0:
            return "Unknown"
        zone_hsv = cv2.cvtColor(zone, cv2.COLOR_BGR2HSV)
        zone_hist = cv2.calcHist([zone_hsv], [0], None, [180], [0, 180])
        dominant_hue = np.argmax(zone_hist)
        
        if dominant_hue < 5 or dominant_hue >= 170:
            return "Red/Pink tones"
        elif 5 <= dominant_hue < 25:
            return "Orange/Brown tones"
        elif 25 <= dominant_hue < 35:
            return "Yellow tones"
        elif 35 <= dominant_hue < 85:
            return "Green tones"
        elif 85 <= dominant_hue < 125:
            return "Blue tones"
        elif 125 <= dominant_hue < 155:
            return "Purple tones"
        else:
            return "Pink tones"
    
    top_color = get_dominant_zone_color(top_third)
    mid_color = get_dominant_zone_color(middle_third)
    bottom_color = get_dominant_zone_color(bottom_third)
    
    garment_layout = {
        "top": top_color,
        "middle": mid_color,
        "bottom": bottom_color,
    }

    return {
        "colors": dominant_colors or [{"name": "Mixed tones", "percentage": None, "swatch": "#b89e91"}],
        "palette_mood": palette_mood,
        "tone_classification": tone_classification,
        "tone_description": tone_description,
        "contrast": contrast_description,
        "style_category": style_category,
        "vibe": vibe,
        "garment_layout": garment_layout,
    }


@app.route('/', methods=['GET', 'POST'])
def index():
    original = None
    analysis = None
    if request.method == 'POST':
        file = request.files.get('image')
        if file and file.filename != '':
            filepath = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filepath)
            
            img = cv2.imread(filepath)
            if img is not None:
                analysis = analyze_outfit_colors(img)
                original = '/' + filepath
                
    return render_template('index.html', original=original, analysis=analysis)

if __name__ == '__main__':
    app.run(debug=True)