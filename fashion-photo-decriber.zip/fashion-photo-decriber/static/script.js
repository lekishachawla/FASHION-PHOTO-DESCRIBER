document.addEventListener("DOMContentLoaded", () => {
    const fileInput = document.getElementById("fileInput");
    const fileName = document.getElementById("fileName");
    const cameraButton = document.getElementById("cameraButton");
    const cameraModal = document.getElementById("cameraModal");
    const closeCameraButton = document.getElementById("closeCamera");
    const captureButton = document.getElementById("captureButton");
    const cameraVideo = document.getElementById("camera");
    const cameraStatus = document.getElementById("cameraStatus");

    if (!fileInput || !fileName || !cameraButton || !cameraModal ||
        !closeCameraButton || !captureButton || !cameraVideo || !cameraStatus) {
        return;
    }

    let cameraStream = null;

    const stopCamera = () => {
        if (cameraStream) {
            cameraStream.getTracks().forEach((track) => track.stop());
            cameraStream = null;
        }
        cameraVideo.srcObject = null;
        captureButton.disabled = true;
    };

    const closeCamera = () => {
        cameraModal.classList.remove("open");
        stopCamera();
    };

    fileInput.addEventListener("change", () => {
        const [file] = fileInput.files;
        if (file) {
            fileName.textContent = file.name;
        }
    });

    cameraButton.addEventListener("click", async () => {
        cameraModal.classList.add("open");
        cameraStatus.textContent = "Waiting for camera permission...";
        captureButton.disabled = true;

        if (!window.isSecureContext) {
            cameraStatus.textContent = "Camera access requires HTTPS or localhost. Open this app at http://127.0.0.1:5000.";
            return;
        }

        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            cameraStatus.textContent = "This browser does not support camera access. Try a recent version of Chrome, Edge, or Firefox.";
            return;
        }

        try {
            cameraStream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: "user" },
                audio: false
            });

            if (!cameraModal.classList.contains("open")) {
                stopCamera();
                return;
            }

            cameraVideo.srcObject = cameraStream;
            await cameraVideo.play();
            cameraStatus.textContent = "Camera is ready. Position yourself, then capture the photo.";
            captureButton.disabled = false;
        } catch (error) {
            stopCamera();
            if (error.name === "NotAllowedError" || error.name === "PermissionDeniedError") {
                cameraStatus.textContent = "Camera permission was denied. Allow camera access in your browser settings, then try again.";
            } else if (error.name === "NotFoundError" || error.name === "DevicesNotFoundError") {
                cameraStatus.textContent = "No camera was found on this device.";
            } else if (error.name === "NotReadableError" || error.name === "TrackStartError") {
                cameraStatus.textContent = "The camera is in use by another app. Close that app and try again.";
            } else {
                cameraStatus.textContent = `Could not open the camera: ${error.message || "Unknown camera error."}`;
            }
        }
    });

    closeCameraButton.addEventListener("click", closeCamera);

    cameraModal.addEventListener("click", (event) => {
        if (event.target === cameraModal) {
            closeCamera();
        }
    });

    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && cameraModal.classList.contains("open")) {
            closeCamera();
        }
    });

    captureButton.addEventListener("click", () => {
        const width = cameraVideo.videoWidth;
        const height = cameraVideo.videoHeight;
        if (!width || !height) {
            cameraStatus.textContent = "The camera is not ready yet. Please wait a moment and try again.";
            return;
        }

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const context = canvas.getContext("2d");
        if (!context) {
            cameraStatus.textContent = "Could not capture the photo in this browser.";
            return;
        }
        context.drawImage(cameraVideo, 0, 0, width, height);

        canvas.toBlob((blob) => {
            if (!blob) {
                cameraStatus.textContent = "Could not create the photo. Please try again.";
                return;
            }

            try {
                const photo = new File([blob], `camera-${Date.now()}.png`, { type: "image/png" });
                const transfer = new DataTransfer();
                transfer.items.add(photo);
                fileInput.files = transfer.files;
                fileName.textContent = photo.name;
                closeCamera();
            } catch (error) {
                cameraStatus.textContent = `Could not attach the captured photo: ${error.message || "Unknown error."}`;
            }
        }, "image/png");
    });
});
